public interface Sellable {
    Double getPrice();
}
